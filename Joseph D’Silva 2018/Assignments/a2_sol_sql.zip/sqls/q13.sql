SELECT COUNT(distinct sid) AS numstudents
FROM enroll
WHERE term = 'winter 2018';
