SELECT ccode, credits
FROM course
WHERE ccode IN
(
  SELECT ccode FROM enroll WHERE term = 'winter 2018' and sid = 12345678
	  EXCEPT
  SELECT ccode FROM enroll WHERE term = 'winter 2018' and sid = 12345679
)
ORDER BY ccode;

