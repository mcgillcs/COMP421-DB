SELECT COUNT(*) as numstudents FROM student;
